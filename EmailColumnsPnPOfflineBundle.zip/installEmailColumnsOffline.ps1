try {    
    Set-ExecutionPolicy Bypass -Scope Process 
    #Prompt for SharePoint URL     
    $SharePointUrl = Read-Host -Prompt 'Enter your SharePoint Site Collection URL to install OnePlace Solutions Email Columns to'
    
    #Connect to site collection
    If($SharePointUrl -match ".sharepoint.com/"){
        Write-Host "Enter SharePoint credentials (your email address for SharePoint Online):" -ForegroundColor Green  
        Connect-pnpOnline -url $SharePointUrl -UseWebLogin
    }
    Else{
        Write-Host "Enter SharePoint credentials (domain\username for on-premises):" -ForegroundColor Green  
        Connect-pnpOnline -url $SharePointUrl 
    }

    $currentDir = (Get-Location).Path
    $Path = "$currentDir\email-columns.xml"
    If(Test-Path $Path) {
        #Apply xml provisioning template to SharePoint
        Write-Host "Applying email columns template to SharePoint:" $SharePointUrl -ForegroundColor Green 
        Apply-PnPProvisioningTemplate -path $Path
    }
    Else {
        Write-Host "'$Path' not found in script directory. Did you extract all files?"
    }
}
catch {
    Write-Host $error[0].Message
}
